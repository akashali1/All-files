package com.book.lending.exception;

public class BookLendingException extends Exception {

	private static final long serialVersionUID = 1L;

	public BookLendingException(String message) {
		super(message);

	}

}
