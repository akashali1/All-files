package com.book.lending.util;

import static com.book.lending.util.BookUtil.BOOK_REQUEST_AVAILABLE;
import static com.book.lending.util.BookUtil.INDIAN_TIME_ZONE;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.book.lending.entity.Book;
import com.book.lending.entity.BookLending;
import com.book.lending.repository.BookLendingRepository;
import com.book.lending.repository.BookRepository;

/**
 * 
 * @author Shiva
 *
 */
@Component
public class Scheduler {
	private static final Logger LOGGER = LoggerFactory.getLogger(Scheduler.class);

	@Autowired
	BookLendingRepository bookLendingRepository;

	@Autowired
	BookRepository bookRepository;

	/**
	 * This method updates the status of book to available if the submission date is
	 * today's date.
	 */
	@Scheduled(fixedRate = 30000)
	public void statusUpdate() {
		
		LOGGER.info("Inside scheduler");
		LocalDate submissionDate = LocalDate.now(ZoneId.of(INDIAN_TIME_ZONE));

		List<BookLending> optBookLending = bookLendingRepository.findBySubmissionDate(submissionDate);
		List<Book> bookList = new ArrayList<>();

		optBookLending.stream().forEach(bookLending -> {
			Integer bookId = bookLending.getBookId();

			Optional<Book> optBook = bookRepository.findById(bookId);
			Book book = optBook.get();
			book.setStatus(BOOK_REQUEST_AVAILABLE);
			bookList.add(book);
		});
		bookRepository.saveAll(bookList);

	}

}
