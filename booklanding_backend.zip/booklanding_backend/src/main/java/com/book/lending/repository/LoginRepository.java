package com.book.lending.repository;

public interface LoginRepository {

}
