package com.medical;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedicalClaimsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedicalClaimsApplication.class, args);
	}

}
