package com.bank.mortagage.util;

public class CustomerUtil {
	
	public final static String CUSTOMER_NOT_FOUND = "Invalid username and password";
	public final static int MONTH = 12;
	public final static int PERSENTAGE = 100;
}
